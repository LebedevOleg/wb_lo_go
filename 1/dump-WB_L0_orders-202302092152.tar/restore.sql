--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "WB_L0_orders";
--
-- Name: WB_L0_orders; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "WB_L0_orders" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1251';


ALTER DATABASE "WB_L0_orders" OWNER TO postgres;

\connect "WB_L0_orders"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliveries (
    name text,
    phone text NOT NULL,
    zip text,
    city text,
    address text,
    region text,
    email text
);


ALTER TABLE public.deliveries OWNER TO postgres;

--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    chrt_id bigint NOT NULL,
    track_number text NOT NULL,
    price bigint,
    rid text,
    name text,
    sale bigint,
    size text,
    total_price bigint,
    nm_id bigint,
    brand text,
    status bigint
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: items_chrt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_chrt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_chrt_id_seq OWNER TO postgres;

--
-- Name: items_chrt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_chrt_id_seq OWNED BY public.items.chrt_id;


--
-- Name: items_to_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items_to_orders (
    item_order_id integer NOT NULL,
    item_id bigint NOT NULL,
    order_id character varying NOT NULL,
    item_track_number text
);


ALTER TABLE public.items_to_orders OWNER TO postgres;

--
-- Name: items_to_orders_item_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.items_to_orders_item_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.items_to_orders_item_order_id_seq OWNER TO postgres;

--
-- Name: items_to_orders_item_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.items_to_orders_item_order_id_seq OWNED BY public.items_to_orders.item_order_id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_uid character varying NOT NULL,
    track_number character varying NOT NULL,
    entry character varying,
    delivery_phone character varying NOT NULL,
    payment_transctions character varying NOT NULL,
    locale character varying,
    internal_signature character varying,
    customer_id character varying,
    delivery_service character varying,
    shardkey character varying,
    sm_id bigint,
    date_created timestamp without time zone,
    oof_shard character varying
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    transaction text NOT NULL,
    request_id text,
    currency text,
    provider text,
    amount bigint,
    payment_dt bigint,
    bank text,
    delivery_cost bigint,
    goods_total bigint,
    custom_fee bigint
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: items chrt_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items ALTER COLUMN chrt_id SET DEFAULT nextval('public.items_chrt_id_seq'::regclass);


--
-- Name: items_to_orders item_order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items_to_orders ALTER COLUMN item_order_id SET DEFAULT nextval('public.items_to_orders_item_order_id_seq'::regclass);


--
-- Data for Name: deliveries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliveries (name, phone, zip, city, address, region, email) FROM stdin;
\.
COPY public.deliveries (name, phone, zip, city, address, region, email) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (chrt_id, track_number, price, rid, name, sale, size, total_price, nm_id, brand, status) FROM stdin;
\.
COPY public.items (chrt_id, track_number, price, rid, name, sale, size, total_price, nm_id, brand, status) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: items_to_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items_to_orders (item_order_id, item_id, order_id, item_track_number) FROM stdin;
\.
COPY public.items_to_orders (item_order_id, item_id, order_id, item_track_number) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_uid, track_number, entry, delivery_phone, payment_transctions, locale, internal_signature, customer_id, delivery_service, shardkey, sm_id, date_created, oof_shard) FROM stdin;
\.
COPY public.orders (order_uid, track_number, entry, delivery_phone, payment_transctions, locale, internal_signature, customer_id, delivery_service, shardkey, sm_id, date_created, oof_shard) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (transaction, request_id, currency, provider, amount, payment_dt, bank, delivery_cost, goods_total, custom_fee) FROM stdin;
\.
COPY public.payments (transaction, request_id, currency, provider, amount, payment_dt, bank, delivery_cost, goods_total, custom_fee) FROM '$$PATH$$/3342.dat';

--
-- Name: items_chrt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_chrt_id_seq', 1, false);


--
-- Name: items_to_orders_item_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.items_to_orders_item_order_id_seq', 32, true);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (phone);


--
-- Name: items items_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pk PRIMARY KEY (chrt_id, track_number);


--
-- Name: items_to_orders items_to_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items_to_orders
    ADD CONSTRAINT items_to_orders_pkey PRIMARY KEY (item_order_id);


--
-- Name: orders order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT order_pkey PRIMARY KEY (order_uid);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (transaction);


--
-- Name: items_to_orders items_to_orders_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items_to_orders
    ADD CONSTRAINT items_to_orders_fk FOREIGN KEY (item_id, item_track_number) REFERENCES public.items(chrt_id, track_number) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: items_to_orders items_to_orders_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items_to_orders
    ADD CONSTRAINT items_to_orders_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_uid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: orders order_delivery_phone_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT order_delivery_phone_fkey FOREIGN KEY (delivery_phone) REFERENCES public.deliveries(phone) ON DELETE CASCADE;


--
-- Name: orders order_payment_transctions_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT order_payment_transctions_fkey FOREIGN KEY (payment_transctions) REFERENCES public.payments(transaction) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

